Run this Lab script command on the workstation machine


1. Log in as the �kubeadmin� user by using the password available 
	[In the classroom environment, the utility machine stores the password for the
kubeadmin user. ssh lab@utility: /home/lab/ocp4/auth/kubeadmin-password file.]

2. Then change in to the directory where the script files available.
   First Run 'project.sh' script to create required projects.

3. Execute startSCENARIO.sh script which will emulate scenario based condition as in the exam.

4. cp newcert to bin path as 
	sudo cp newcert /usr/bin
	sudo chmod a+x /usr/bin/newcert

5. Run 'lab start network-policy' as student@workstation.

5. Once done with all the question delete the lab and recreate.

